<div
    class="product-thumbs swiper-wrapper row cols-4 gutter-sm"
>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/1-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/2-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/3-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/4-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/5-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
    <div class="product-thumb swiper-slide">
        <img
            src="{{ asset('assets/images/products/default/6-800x900.jpg') }}"
            alt="Product Thumb"
            width="800"
            height="900"
        />
    </div>
</div>
<button class="swiper-button-next"></button>
<button class="swiper-button-prev"></button>
