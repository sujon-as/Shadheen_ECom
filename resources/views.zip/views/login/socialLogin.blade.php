<p class="text-center">Sign in with social account</p>
<div
    class="social-icons social-icon-border-color d-flex justify-content-center"
>
    <a
        href="#"
        class="social-icon social-facebook w-icon-facebook"
    ></a>
    <a
        href="#"
        class="social-icon social-twitter w-icon-twitter"
    ></a>
    <a
        href="#"
        class="social-icon social-google fab fa-google"
    ></a>
</div>
